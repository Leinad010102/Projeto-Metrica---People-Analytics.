import streamlit as st
from plotters.radar_chart import person_radar_chart
from sklearn.neighbors import NearestNeighbors

def user_radar_chart(df, user_name):
    df_user = df.loc[df['Nomes'] == user_name]
    
    if df_user.empty:
        st.error("Usuário não encontrado.")
        return

    # Obtém as habilidades do usuário
    array_without_name_by_user_name = df_user.iloc[:, 1:].to_numpy()[0]  # Pega o primeiro (e único) usuário

    st.subheader(f"Gráfico Radar para {user_name}")
    
    # Passa o índice das habilidades para o gráfico
    skills = df.columns[1:]  # Supondo que a primeira coluna é 'Nomes'
    
    radar_fig_user = person_radar_chart(array_without_name_by_user_name, max=5, person_name=user_name, labels=skills)
    st.pyplot(radar_fig_user)

    # Encontrar os vizinhos mais próximos
    df_without_user = df.loc[df['Nomes'] != user_name]
    df_without_column_name_and_current_user = df_without_user.iloc[:, 1:].to_numpy()
    
    if df_without_column_name_and_current_user.shape[0] > 0:
        knn = NearestNeighbors()
        knn.fit(df_without_column_name_and_current_user)
        result = knn.kneighbors([array_without_name_by_user_name])

        st.write(f"Resultados para {user_name}:")
        st.dataframe(df_without_user.iloc[result[1][0]])
    else:
        st.error("Não há dados suficientes para calcular vizinhos.")
