import numpy as np
import matplotlib.pyplot as plt

def person_radar_chart(person, max=5, person_name='Média do time', labels=None):
    angles = np.linspace(0, 2 * np.pi, len(person), endpoint=False)
    stats = np.concatenate((person, [person[0]]))
    angles = np.concatenate((angles, [angles[0]]))
    
    if labels is None:
        labels = [f'Skill {i+1}' for i in range(len(person))]  # Default labels se não forem fornecidas

    labels = np.concatenate((labels, [labels[0]]))

    fig = plt.figure(figsize=(6, 6))
    ax = fig.add_subplot(111, polar=True)
    ax.plot(angles, stats, 'o-', linewidth=2)
    ax.fill(angles, stats, alpha=0.25)
    ax.set_thetagrids(angles * 180 / np.pi, labels)
    ax.set_title(person_name)
    ax.set_rlim(0, max)
    ax.grid(True)
    
    return fig

