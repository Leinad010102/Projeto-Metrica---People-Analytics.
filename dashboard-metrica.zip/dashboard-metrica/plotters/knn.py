import streamlit as st
from sklearn.neighbors import NearestNeighbors

def knn_analysis(df):
    target_skills = st.text_input("Digite as habilidades (separadas por vírgula):", "5,-10,-10,5,5")
    target_skills = list(map(int, target_skills.split(',')))

    if len(target_skills) != df.shape[1] - 1:  # Ajuste para o número correto
        st.error(f"O vetor targetSkills deve ter {df.shape[1] - 1} elementos.")
    else:
        array_without_names = df.iloc[:, 1:].to_numpy()
        knn = NearestNeighbors(n_neighbors=min(5, df.shape[0]))
        knn.fit(array_without_names)
        result = knn.kneighbors([target_skills])
        st.write("Resultados KNN:")
        if 'Nomes' in df.columns:
            df_result = df.iloc[result[1][0]].set_index('Nomes')
            st.dataframe(df_result)
        else:
            st.error("A coluna 'Nomes' não existe no DataFrame.")
