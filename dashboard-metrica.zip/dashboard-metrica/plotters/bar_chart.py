import matplotlib.pyplot as plt

def plot_bar_chart(means):
    fig, ax = plt.subplots(figsize=(8, 4))
    means.plot.bar(ax=ax, rot=60)
    ax.set_ylim(0, 5)
    plt.xlabel("Skills")
    plt.ylabel("Média")
    plt.tight_layout()
    return fig
