import os
import pandas as pd
import glob

def load_data():
    file = max(glob.glob("./content/habilidades.csv"), key=os.path.getmtime)
    df = pd.read_csv(file)
    return df
