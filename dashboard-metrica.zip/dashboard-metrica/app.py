import streamlit as st
import pandas as pd
from data_loader import load_data  # Certifique-se de que esse arquivo existe
from plotters.bar_chart import plot_bar_chart
from plotters.knn import knn_analysis
from plotters.radar_chart import person_radar_chart
from plotters.user_radar_chart import user_radar_chart

# Configuração do Streamlit
st.title("Análise de Habilidades")
df = load_data()

# Exibir descrição dos dados
st.subheader("Descrição dos Dados")
st.write(df.describe())

# Calcular médias
df_mean = df.select_dtypes(include='number').mean().round(2)

# Sidebar para navegação
menu = st.sidebar.selectbox("Escolha uma visualização:", 
                             ["Média do time por skills", 
                              "Gráfico Radar da Média do Time", 
                              "K-NN: Encontrar Vizinhos Mais Próximos",
                              "Gráfico Radar do Usuário",
                              "Tabela de Análise das Habilidades"])

# Gráfico de barras
if menu == "Média do time por skills":
    st.subheader("Média do time por skills")
    bar_fig = plot_bar_chart(df_mean)
    st.pyplot(bar_fig)

# Gráfico radar da média do time
elif menu == "Gráfico Radar da Média do Time":
    st.subheader("Gráfico Radar da Média do Time")
    radar_fig = person_radar_chart(df_mean, person_name="Média do time")
    st.pyplot(radar_fig)

# K-NN
elif menu == "K-NN: Encontrar Vizinhos Mais Próximos":
    st.subheader("K-NN: Encontrar Vizinhos Mais Próximos")
    knn_analysis(df)

# Gráfico Radar do Usuário
elif menu == "Gráfico Radar do Usuário":
    user_name = st.selectbox("Escolha um usuário:", df['Nomes'])
    if user_name:
        user_radar_chart(df, user_name)

# Tabela de Análise das Habilidades
elif menu == "Tabela de Análise das Habilidades":
    st.subheader("Tabela de Análise das Habilidades")
    st.dataframe(df)
